class PagesController < ApplicationController
    #set controller for each page
    def home   
    end
    
    def about
    end
end