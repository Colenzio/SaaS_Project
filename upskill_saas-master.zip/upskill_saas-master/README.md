# README

Software-as-a-Service Ruby on Rails App where entrepenuers cant meet developers